# All-in-One AI Studio (Free-first starter)

A browser-first Next.js workspace with:
- Dashboard and modules for scripts/SEO, media prompts, local video preview, audio/subtitle workflow, YouTube metadata.
- Server-side AI route for Cloudflare Workers AI or Gemini.
- Strict behavior: provider errors/quota exhaustion stop; no paid fallback.
- Secrets are read only from server environment variables.

## Important: honest feature status
This is a working starter, not a finished commercial-grade editor.
- Script and SEO generation can work after configuring a compatible provider and valid free-tier credentials.
- Image/video page currently prepares prompts; it does not generate video.
- Editor currently imports and previews a local video; timeline editing and rendering/export are not implemented.
- Audio page prepares scripts; TTS/STT/dubbing integrations are not yet implemented.
- YouTube page exports metadata; OAuth upload/scheduling/analytics are not implemented.
- No account, key, payment, or paid service has been created.

## Run locally
1. Install Node.js 20+.
2. Extract ZIP and open terminal in the project folder.
3. Run `npm install`
4. Copy `.env.example` to `.env.local`
5. Add one provider's server-side credentials.
6. Run `npm run dev`, then open http://localhost:3000

## Cloudflare Workers AI
Set `CLOUDFLARE_ACCOUNT_ID` and `CLOUDFLARE_API_TOKEN` in `.env.local` or hosting environment.
The API route uses `@cf/meta/llama-3.1-8b-instruct`. Check the current Cloudflare model catalogue and free quota before use. A quota or provider error returns an error and never switches to paid.

## Gemini
Alternatively set `GEMINI_API_KEY`. The route calls Gemini 2.0 Flash. Check the current model availability, region access, free-tier eligibility and data-use terms before enabling. Do not use a `NEXT_PUBLIC_` prefix for secrets.

## Deploy
Deploy this Next.js project to a Node-compatible host. Add environment variables in the host's server-side settings. Do not commit `.env.local`.
A live public URL is not included: deployment requires your hosting account authorization and a destination project.

## Security and limitations
- Never paste API keys into chat or commit them to GitHub.
- Free quotas and model availability can change.
- API key access does not guarantee free commercial rights; verify model/provider terms.
- The project intentionally has no paid fallback.
