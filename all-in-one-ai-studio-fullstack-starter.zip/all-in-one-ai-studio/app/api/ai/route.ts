import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";
const ALLOWED = new Set(["script","seo"]);
function noPaidFallback(){ return NextResponse.json({error:"No free provider configured or available. Paid fallback is disabled."},{status:503}); }
export async function POST(req:NextRequest){
 try{
  const body=await req.json(); const kind=String(body.kind||""); const prompt=String(body.prompt||"").slice(0,12000); const language=String(body.language||"English").slice(0,40);
  if(!ALLOWED.has(kind)) return NextResponse.json({error:"Unsupported task."},{status:400});
  const account=process.env.CLOUDFLARE_ACCOUNT_ID, token=process.env.CLOUDFLARE_API_TOKEN;
  if(account && token){
   const model="@cf/meta/llama-3.1-8b-instruct";
   const system=kind==="seo"?"Return valid JSON only with keys title, description, tags (array). Create accurate YouTube metadata.":"Write a clear, original video script with scene directions.";
   const r=await fetch(`https://api.cloudflare.com/client/v4/accounts/${account}/ai/run/${model}`,{method:"POST",headers:{"Authorization":`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({messages:[{role:"system",content:system+` Output language: ${language}.`},{role:"user",content:prompt}]})});
   const data=await r.json(); if(!r.ok || !data.success) return NextResponse.json({error:"Free provider request failed or quota reached. No paid fallback was used."},{status:429});
   const text=data.result?.response||"";
   if(kind==="seo"){try{return NextResponse.json(JSON.parse(text));}catch{return NextResponse.json({error:"Provider returned invalid SEO JSON. Please retry."},{status:502});}}
   return NextResponse.json({text});
  }
  if(process.env.GEMINI_API_KEY){
   const r=await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key="+encodeURIComponent(process.env.GEMINI_API_KEY),{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:(kind==="seo"?"Return valid JSON only with keys title, description, tags (array). ":"Write a clear original video script. ")+`Output language: ${language}. `+prompt}]}]})});
   const data=await r.json(); if(!r.ok) return NextResponse.json({error:"Gemini request failed or free quota reached. No paid fallback was used."},{status:429});
   const text=data.candidates?.[0]?.content?.parts?.map((p:any)=>p.text||"").join("")||"";
   if(kind==="seo"){try{return NextResponse.json(JSON.parse(text));}catch{return NextResponse.json({error:"Provider returned invalid SEO JSON."},{status:502});}}
   return NextResponse.json({text});
  }
  return noPaidFallback();
 }catch{return NextResponse.json({error:"Invalid request."},{status:400});}
}