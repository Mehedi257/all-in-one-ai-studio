import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "All-in-One AI Studio", description: "Free-first AI creator workspace" };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }